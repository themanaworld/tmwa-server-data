<?xml version="1.0" encoding="UTF-8"?>
<tileset name="crypt_x8" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/crypt_x8.png" width="192" height="256"/>
</tileset>
