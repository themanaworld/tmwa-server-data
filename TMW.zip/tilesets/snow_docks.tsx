<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snow_docks" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/snow_docks.png" width="512" height="320"/>
</tileset>
