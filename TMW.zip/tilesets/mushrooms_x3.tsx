<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="mushrooms_x3" tilewidth="32" tileheight="96" tilecount="40" columns="20">
 <image source="../graphics/tiles/mushrooms_x3.png" width="640" height="224"/>
</tileset>
