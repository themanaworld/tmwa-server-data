<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="mushrooms_x2" tilewidth="32" tileheight="64" tilecount="60" columns="20">
 <image source="../graphics/tiles/mushrooms_x2.png" width="640" height="224"/>
</tileset>
